Ref Project
===========
	FaresFlightTickets from microservices workspace
	
Modified/Added files
===================
	pom.xml						[modified]
	application.properties		[modified]
	OAuth2ResourceServer.java	[new]
	Application.java			[modified]
		
	