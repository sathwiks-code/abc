package com.brownfield.pss.checkin.component;

public class BookingStatus {
	public static final String CHECKED_IN = "CHECKED_IN"; 

}
